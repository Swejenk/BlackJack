﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
 * Jens Malm 
 * 2016-09
 * BlackJackGame
 **/
namespace Model.EnumTypes
{
    public enum FaceType
    {
        Jack = 11,
        Queen = 12,
        King = 13,
        Ace = 1
    }
    public enum ImageFileFaceDefinition
    {
        j = 11,
        q = 12,
        k = 13
    }
}
